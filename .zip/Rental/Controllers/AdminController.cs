﻿namespace Rental.Controllers
{
    public class AdminController
    {
    }
}
