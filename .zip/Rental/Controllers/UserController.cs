﻿namespace Rental.Controllers
{
    public class UserController
    {
    }
}
