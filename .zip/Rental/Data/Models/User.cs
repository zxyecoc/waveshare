﻿using Microsoft.AspNetCore.Identity;

namespace Rental.Data.Models
{
    public class User : IdentityUser
    {
    }
}
