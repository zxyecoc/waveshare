﻿using Rental.Data.Models;

namespace Rental.Data.interfaces
{
    public interface ICarsCategory
    {
        IEnumerable<Category> AllCategories { get; }

    }
}