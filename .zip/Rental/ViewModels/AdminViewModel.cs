﻿namespace Rental.ViewModels
{
    public class AdminViewModel
    {
    }
}
